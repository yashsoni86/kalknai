import React, { useState, useEffect, useRef } from 'react';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { InputText } from "primereact/inputtext";
import axios from "axios";
import { Toast } from 'primereact/toast';
import { Image } from 'primereact/image';
import { Button } from 'primereact/button';
import { DataView } from 'primereact/dataview';
import { Rating } from 'primereact/rating';
import { Tag } from 'primereact/tag';

export default function PaginatorBasicDemo() {
    const toast = useRef(null);
    const showError = (msg) => {
        toast.current.show({ severity: 'error', summary: 'Error', detail: msg, life: 3000 });
    }
    const [searchedData, setSearchedData] = useState([]);
    const [searchedValue, setSearchedValue] = useState("");
    const baseURL = "https://api.jikan.moe/v4/characters?page=0&limit=12&order_by=favorite&sort=desc&q=";

    //for enter pressed in search box 
    const onKeyPressed = (value) => {
        if (value.key == "Enter") {
            setSearchedValue(value.target.value);
            setSearchedData([]);
            axios.get(baseURL + value.target.value).then((response) => {
                if (response.status == "200") {
                    setSearchedData(response.data.data);
                }
                else {
                    showError(response.statusText);
                    setSearchedData([]);
                }

            })
        }
    }

    //open link on new tab
    const linkButtonClicked = (e) => {
        window.open(e, "_blank");
    }

    //items html
    const itemTemplate = (product) => {
        return (
            <div className="col-12 grid">
                <div className="col-11" style={{ border: "1px solid" }}>
                    <div className="flex flex-column xl:flex-row xl:align-items-start p-4 gap-4">
                        <Image className="shadow-2 block xl:block mx-auto border-round"
                            src={product.images.jpg.image_url} alt={product.name} preview />
                        <div className="flex flex-column sm:flex-row justify-content-between align-items-center xl:align-items-start flex-1 gap-4">
                            <div className="flex flex-column align-items-center sm:align-items-start gap-3">
                                <div className="text-2xl font-bold text-900">{product.name}</div>
                                <div className="flex align-items-center gap-3">
                                    {
                                        product.nicknames.map(e => <span className="flex align-items-center gap-2" style={{ background: "#9899b357" }}>
                                        <span className="font-semibold">{e}</span>
                                    </span>)
                                    }
                                </div>
                            </div>
                            <div className="flex sm:flex-column align-items-right sm:align-items-end gap-3 sm:gap-2">
                                {product.favorites > 0 ? <i className="pi pi-heart-fill" style={{ fontSize: '2rem' }}>{product.favorites}</i> : ""}
                            </div>
                        </div>
                    </div>
                </div>
                <div className="col-1" style={{ border: "1px solid" }}>
                    <div className="flex sm:flex-column align-items-center sm:align-items-end gap-3 sm:gap-2 p-4 gap-4">
                        <Button icon="pi pi-window-maximize" onClick={() => linkButtonClicked(product.url)} ></Button>
                    </div>
                </div>
            </div>
        );
    };

    return (
        <>
            <div className="card" style={{ textAlign: 'center' }}>
                <span className="p-input-icon-left">
                    <i className="pi pi-search" />
                    <InputText placeholder="Press Enter After Search Values Entered To Search" onKeyPress={onKeyPressed} style={{ width: "600px" }} />
                </span>
                <h4>Total {searchedData.length} matching {searchedValue} anime character found</h4>
            </div>

            <hr></hr>

            {/* only show view when data is available */}
            {searchedData.length > 0 ?
                <DataView value={searchedData} itemTemplate={itemTemplate} /> : <center><h3 className="blink">No Results Found...!</h3></center>}

        </>
    );
}
